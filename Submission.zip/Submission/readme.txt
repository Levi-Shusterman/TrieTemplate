Compile on a linux system (bertvm, ernievm)
g++ -w -std=c++11 demo.cpp

Templated trie data structure -- generic programming